package com.studentdata.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        // Keep the WebView's normal cache so the app can reuse previously
        // downloaded web resources when the network is temporarily unavailable.
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new AndroidFileBridge(), "AndroidFile");
        webView.setWebViewClient(new OfflineWebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // Handles normal http(s) downloads.
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            // Blob downloads are handled by the injected JavaScript bridge below.
            if (url != null && !url.startsWith("blob:")) {
                Toast.makeText(this, "جاري تنزيل الملف…", Toast.LENGTH_SHORT).show();
            }
        });

        webView.loadUrl("https://student-data-manager.youware.app/");
    }

    private void installDownloadBridge() {
        String js =
            "(function(){try{" +
            "if(window.__studentDownloadBridgeInstalled)return;" +
            "window.__studentDownloadBridgeInstalled=true;" +
            "function sendBlob(blob,name,mime){" +
            " var r=new FileReader();" +
            " r.onloadend=function(){try{var s=r.result||'';var i=s.indexOf(',');" +
            "AndroidFile.saveBase64(name,mime,i>=0?s.substring(i+1):s);" +
            "}catch(e){console.error(e);}};" +
            " r.readAsDataURL(blob);" +
            "}" +
            "document.addEventListener('click',function(e){" +
            " var a=e.target.closest&&e.target.closest('a[download]');" +
            " if(!a)return;" +
            " var href=a.href||'';var name=a.getAttribute('download')||'student-data.xlsx';" +
            " if(href.indexOf('blob:')===0){" +
            "  e.preventDefault();e.stopPropagation();" +
            "  fetch(href).then(function(x){return x.blob();}).then(function(b){sendBlob(b,name,b.type||'application/octet-stream');});" +
            " }" +
            "},true);" +
            // Some apps programmatically click a hidden download anchor.
            "var oldClick=HTMLAnchorElement.prototype.click;" +
            "HTMLAnchorElement.prototype.click=function(){" +
            " var a=this,href=a.href||'',name=a.download||'student-data.xlsx';" +
            " if(href.indexOf('blob:')===0){" +
            "  fetch(href).then(function(x){return x.blob();}).then(function(b){sendBlob(b,name,b.type||'application/octet-stream');});" +
            "  return;" +
            " }" +
            " return oldClick.apply(this,arguments);" +
            "};" +
            "}catch(e){console.error(e);}})();";

        webView.evaluateJavascript(js, null);
    }

    private class OfflineWebViewClient extends WebViewClient {
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            installDownloadBridge();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            if (request.isForMainFrame()) {
                // Try the WebView cache when the main page cannot be reached.
                view.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
            }
        }
    }

    private class AndroidFileBridge {
        @JavascriptInterface
        public void saveBase64(String fileName, String mimeType, String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safeName = fileName == null || fileName.trim().isEmpty()
                        ? "student-data.xlsx" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (!safeName.toLowerCase(Locale.ROOT).endsWith(".xlsx")
                        && mimeType != null && mimeType.contains("spreadsheet")) {
                    safeName += ".xlsx";
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE,
                            mimeType == null ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);

                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Could not create download");

                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Could not open download");
                        out.write(bytes);
                    }

                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create Downloads");
                    File file = new File(dir, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        out.write(bytes);
                    }
                }

                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this,
                                "تم حفظ ملف Excel في مجلد التنزيلات Downloads",
                                Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this,
                                "تعذر حفظ ملف Excel: " + e.getMessage(),
                                Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
